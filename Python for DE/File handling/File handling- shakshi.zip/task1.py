# Task 1: Create a File
with open("students.txt", "w") as file:
    file.write("Name, Age, Grade\n")
    file.write("John, 20, A\n")
    file.write("Alice, 19, B\n")
    file.write("Mark, 21, A\n")
    file.write("Sophie, 22, C\n")
