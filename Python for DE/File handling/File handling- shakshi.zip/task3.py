# Task 3: Append Data to the File
with open("students.txt", "a") as file:
    file.write("Emma, 20, B\n")
    file.write("Liam, 23, A\n")
